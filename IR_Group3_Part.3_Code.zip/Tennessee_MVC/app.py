from flask import *
from sentence_transformers import util
from os.path import abspath, join
import torch
import pandas as pd
from models.trainable_dense_models import BiEncoder
from tqdm import tqdm
tqdm.pandas(desc='Processing text')


app = Flask(__name__)

documents_df = pd.read_csv(abspath(join(__file__, "../wikir_en1k_passage.csv")))
documents = list(documents_df.article)

checkpoint_path = abspath(join(__file__, "../output/training/Mar05-11-34-46/30"))
model = BiEncoder.load(checkpoint_path)

device=torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
batch_size=512


d_embeddings = model.d_encoder.encode(texts=documents, device=device, batch_size=batch_size)
score_fn = util.dot_score if model.score_fn == 'dot' else util.cos_sim

@app.route('/')
def hello_world():
    return render_template('search.html')


@app.route('/search', methods=['GET', 'POST'])
def search():

    search_result=[]


    if request.method== 'POST':

        keyword= request.form['keyword']

        q_embeddings = model.q_encoder.encode(texts=keyword, device=device, batch_size=batch_size)

        all_results = util.semantic_search(
            query_embeddings=q_embeddings,
            corpus_embeddings=d_embeddings,
            top_k=10,
            score_function=score_fn)
        all_results = [[result['corpus_id'] for result in results] for results in
                       all_results] 

        res = []
        for i in all_results[0]:
            print(i)
            id, article = documents_df.loc[i, :]

            res.append({'url': 'article?id='+str(id), 'title': article[:35].title(), 'content': article[:600].capitalize() + "..." if len(article) > 600 else article.capitalize(), 'create_data': str(id)})

        search_result.extend(res)

        search_nums= len(search_result)
        print(search_result)
        print(documents_df)
        return render_template('search_result.html',search_result=search_result, search_nums=search_nums, keyword=keyword)
    return render_template('search.html')


@app.route('/article')
def return_passage():
    query_id = request.args.get('id')
    print(query_id,type(query_id))
    article = documents_df.loc[documents_df['id'] == int(query_id)].iat[0,1]
    print(type(article), article)
    return render_template('search_passage.html', results=article.capitalize())



if __name__ == '__main__':
    app.run()
