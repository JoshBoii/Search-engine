import ir_datasets
from tqdm import tqdm
from rank_bm25 import BM25Okapi
import pandas as pd


class My_BM25:
    def bm25_model(self):
        dataset = ir_datasets.load("wikir/en1k")
        tokenized_corpus = []
        corpus = []
        doc_id_list = []
        for doc in tqdm(dataset.docs_iter(), total=dataset.docs_count()):
            corpus.append(doc.text)
            doc_id_list.append(doc[0])
            tokenized_corpus.append(doc.text.split(" "))
        bm25 = BM25Okapi(tokenized_corpus)
        return bm25, corpus, tokenized_corpus, doc_id_list

    def __init__(self):
        self.model, self.corpus, self.token_corpus, self.doc_id = My_BM25.bm25_model(self)

    def my_bm25_retrival(self, query, n):
        tokenized_query = query.split(" ")
        return self.model.get_top_n(tokenized_query, self.doc_id, n=n)


class My_BM25_test(My_BM25):

    def __init__(self, benchmark):
        super(My_BM25_test, self).__init__()
        self.benchmark = pd.read_csv(benchmark, index_col=0)

    def model_precision(self, query_text, bench):
        precision_res = []  # P@5, P@10, P@20, P@100, P@200,P@500
        for n in (5, 10, 20, 100, 200, 500):
            res_list = self.my_bm25_retrival(query_text, n)
            score = sum([1 if int(a) in bench else 0 for a in res_list])
            precision_res.append(score / n)
        return precision_res

    def model_recall(self, query_text, bench):
        recall_res = []  # R@100, R@200, R@500
        for n in (100, 200, 500):
            res_list = self.my_bm25_retrival(query_text, n)
            score = sum([1 if int(a) in bench else 0 for a in res_list])
            recall_res.append(score / len(bench))
        return recall_res

    def evaluation_analysis(self):
        df = pd.read_csv('my_bm25_evaluation.csv', index_col=0)
        for name in ['P@5', 'P@10', 'P@20', 'P@100', 'P@200', 'P@500', 'R@100', 'R@200', 'R@500']:
            res = df[name].mean()
            print('{} of my BM25 model is {:.4f}'.format(name, res))

    def my_bm25_evaluation(self):
        res_dict = {}
        for row in tqdm(self.benchmark.iterrows(), total=len(self.benchmark.index)):
            query_text, bench_res = row[1]
            bench_res = [int(a) for a in bench_res.split(',')]
            precision_res = self.model_precision(query_text, bench_res)
            recall_res = self.model_recall(query_text, bench_res)
            res_dict.update({row[0]: precision_res + recall_res})
        df_res = pd.DataFrame(res_dict,
                              index=['P@5', 'P@10', 'P@20', 'P@100', 'P@200', 'P@500', 'R@100', 'R@200', 'R@500'])
        df = pd.concat([self.benchmark, df_res.T], axis=1)
        df.to_csv('my_bm25_evaluation.csv')
        self.evaluation_analysis()


if __name__ == '__main__':
    # this is my BM25 test part
    benchmark_file = 'benckmark.csv'
    a = My_BM25_test(benchmark_file)
    a.my_bm25_evaluation()

    b = My_BM25()

    # the input way depends on you, I just leave it here
    query = 'semiotics'
    n = 10

    res = b.my_bm25_retrival(query, n)
    print(res)
