#Text Preprocessing

import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

#Tokenize the text
tokens = nltk.word_tokenize(text)

#Lowercase the tokens
tokens = [token.lower() for token in tokens]

#Remove stopwords
stop_words = set(stopwords.words('english'))
tokens = [token for token in tokens if token not in stop_words]

#Stem the tokens
stemmer = PorterStemmer()
tokens = [stemmer.stem(token) for token in tokens]

/////////////////////////////////////////////////////
#Term Frequency Calculation
from collections  import Counter 

#Count the frequency of each term
tf = Counter(tokens)

//////////////////////////////////////////////////////
#Inverse Document Frequency Calculation
import math

#Calculate the IDF for each term
num_docs = len(documents)
idf = {}
for term in tf:
    doc_count = sum(1 for doc in documents if term in doc)
    idf[term] = math.log(num_docs / doc_count)

//////////////////////////////////////////////////////
#TD-IDF Calculation
# Calculate the TD-IDF score for each term in each document
tdidf = {}
for i, doc in enumerate(documents):
    tdidf[i] = {}
    for term in tf:
        tfidf = tf[term] * idf[term]
        tdidf[i][term] = tfidf
////////////////////////////////////////////////////////
# Rank the documents by TD-IDF score
ranked_docs = sorted(tdidf.items(), key=lambda x: sum(x[1].values()), reverse=True)

